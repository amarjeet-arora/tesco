package com.service;

import com.entity.EmpInsurance;

public interface InsuranceService {
	public void registerUserHealthInsurance(EmpInsurance emp);

}
