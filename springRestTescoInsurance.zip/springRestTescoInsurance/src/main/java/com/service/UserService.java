package com.service;

import com.entity.User;

public interface UserService {
	public void addEmployee(User user);
}
