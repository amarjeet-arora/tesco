package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.InsuranceDao;
import com.entity.EmpInsurance;
@Service
public class InsuranceServiceImpl implements InsuranceService {

	@Autowired
	private InsuranceDao insuranceDao;
	
	@Override
	public void registerUserHealthInsurance(EmpInsurance emp) {
		insuranceDao.registerUserHealthInsurance(emp);
		
	}

}
