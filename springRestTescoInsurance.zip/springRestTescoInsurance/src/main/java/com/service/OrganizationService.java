package com.service;

import com.entity.EmpInsurance;
import com.entity.User;

public interface OrganizationService {
	
	public void joinOrganization(User usr,EmpInsurance ins);

}
