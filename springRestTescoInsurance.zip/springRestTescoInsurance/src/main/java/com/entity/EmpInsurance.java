package com.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class EmpInsurance {
	@Id
	private String name;
	private String schemeName;
	private int coverageAmount;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSchemeName() {
		return schemeName;
	}
	public void setSchemeName(String schemeName) {
		this.schemeName = schemeName;
	}
	public int getCoverageAmount() {
		return coverageAmount;
	}
	public void setCoverageAmount(int coverageAmount) {
		this.coverageAmount = coverageAmount;
	}
	

}
