package com.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.entity.EmpInsurance;
@Repository
public interface InsuranceRepo extends CrudRepository<EmpInsurance, String>{

}
