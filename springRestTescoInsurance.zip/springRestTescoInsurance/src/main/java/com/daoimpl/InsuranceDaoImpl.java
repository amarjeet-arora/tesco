package com.daoimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dao.InsuranceDao;
import com.entity.EmpInsurance;
import com.repo.InsuranceRepo;
 @Component
public class InsuranceDaoImpl implements InsuranceDao{

	
	@Autowired
	private InsuranceRepo ir;
	@Override
	public void registerUserHealthInsurance(EmpInsurance emp) {
		ir.save(emp);
		
	}

}
