package com.daoimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.dao.UserDao;
import com.entity.User;
import com.repo.UserRepo;

@Component
public class UserDaoImpl implements UserDao {

	@Autowired
	private UserRepo userRepo;
	@Override
	public void addEmployee(User user) {
		userRepo.save(user);
		
	}

}
