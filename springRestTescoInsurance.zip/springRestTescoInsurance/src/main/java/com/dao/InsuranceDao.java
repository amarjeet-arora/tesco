package com.dao;

import com.entity.EmpInsurance;

public interface InsuranceDao {
	
	public void registerUserHealthInsurance(EmpInsurance emp);

}
