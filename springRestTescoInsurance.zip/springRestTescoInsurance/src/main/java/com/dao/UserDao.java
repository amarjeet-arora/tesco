package com.dao;

import com.entity.User;

public interface UserDao {
	public void addEmployee(User user);

}
