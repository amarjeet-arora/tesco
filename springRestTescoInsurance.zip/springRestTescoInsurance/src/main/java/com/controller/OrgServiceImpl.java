package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.entity.EmpInsurance;
import com.entity.User;
import com.service.InsuranceService;
import com.service.OrganizationService;
import com.service.UserService;

@RestController
@RequestMapping("/mainapp")
public class OrgServiceImpl implements OrganizationService{

@Autowired
 UserService userService;
 @Autowired
 InsuranceService insService;

	@Override
	@GetMapping("/addusertoorg")
	public void joinOrganization(User usr, EmpInsurance ins) {
		User user= new User();
		
		user.setName("admin");
		user.setEmail("aa@mm.com");
		user.setCity("mumbai");
		user.setPassword("pass@123");
		
		EmpInsurance ei= new EmpInsurance();
		ei.setName("admin");
		ei.setCoverageAmount(200000);
		ei.setSchemeName("premium");
		
		userService.addEmployee(user);
		
		if(user.getName().equals("admin")) {
			throw new RuntimeException("transaction rollback");
		}
		insService.registerUserHealthInsurance(ins);
		
		
	}

}
